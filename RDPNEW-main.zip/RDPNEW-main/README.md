# WINRDP

WELLCOME TO DEVIL HACKS
How to use 

Just Fork this Repository, Go to Actions tab, Select the Windows-CRD workflow. Then select Run Workflow fill the following data in CRD Code and your Pin in the fields. After that, Press Start.

Input the following code in the fields.

Get the Windows (Powershell) command from here:

https://file.technicalatg.com/K5dr

Enter you Six digit Pin code to Login

(Any Six digit Pin)

Thats it... After 2-3 min of Initialize, Check your CRD Application or Account.
